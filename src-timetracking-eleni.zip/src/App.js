import './App.css';
import Login from './components/Login';
import Timer from './components/Timer'
import { useState } from 'react';

//data structure

let users = [
  {
    userName: 'Mario',
    password: '123'
  },
  {
    userName: 'Luigi',
    password: '456'
  }
]

let logData = [
  {
    startDate: '',
    startTime: '',
    endTime:'',
    userName:'Eleni',
    projectName:'My first project'
  },
  {
    startDate: '',
    startTime: '',
    endTime:'',
    userName:'Eleni',
    projectName:'My second project'
  },
  {
    startDate: '',
    startTime: '',
    endTime:'',
    userName:'Lula',
    projectName:'My third project'
  }
]

function App() {
let currentUser = '';

function showUser() {
  alert(currentUser);
}

  return (
    <div className="App">
      <Login users = {users} currentUser = {currentUser}/>
      <Timer logData = {logData}/>
    </div>
  );
}

export default App;