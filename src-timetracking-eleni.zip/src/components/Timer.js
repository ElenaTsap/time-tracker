import './Timer.css'
import { useState } from 'react';

export default function (props) {
    const [timerOn, setTimerOn] = useState(false);
    const [currentProject, setCurrentProject] = useState('null');
    let durationMS;
    let isNewProject;
    
    function logHandler() {
        let date = new Date();
        let time = date.getTime();

        if (timerOn == false) {
            setTimerOn(true)
            props.logData.push(
                {
                    startDate: date,
                    startTime: time,
                    endTime:'',
                    userName:'Eleni',
                    projectName:''
                }
            )
        } else {
            setTimerOn(false)
            props.logData[1].endDate = date;
            props.logData[1].endTime = time;

            durationMS = props.logData[1].endTime - props.logData[1].startTime;
            console.log(typeof durationMS);
            props.logData[1].duration = msToMinutesAndSeconds(durationMS)
            console.log(durationMS);
            console.log(props.logData[1].duration);
            console.log(msToMinutesAndSeconds);
        }
        console.log(date, time);
        console.log(props.logData);
    }

    function msToMinutesAndSeconds(duration) {
        let minutes = Math.floor(duration / 60000);
        let seconds = ((duration % 60000) / 1000).toFixed(0);
        return minutes + ":" + (seconds < 10 ? '0' : '') + seconds;
    }

    function addProject() {
        isNewProject = true;
    }

    let currentUserProjects = props.logData.filter(log => log.userName === 'Eleni').map(item => <option>{item.projectName}</option>);

    return (
        <div  className = 'timer-container'>

            <section>
                <h1>Select a project or add a new one</h1>
                <select onChange={(e)=>setCurrentProject(e.target.value)}>
                    {currentUserProjects}
                </select>
                <input onChange={(e)=>setCurrentProject(e.target.value)}/>
                <button className='add-button' onClick = {addProject}>Add</button>
            </section>

            <section>
                {currentProject}
                {
                timerOn ?        
                <button className='stop-button' onClick={logHandler}>Stop</button>
                :<button className='start-button' onClick={logHandler}>Start</button>
                }
            </section>

        </div>

    )
}